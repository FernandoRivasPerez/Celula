/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package celula.tablero;

import java.util.Scanner;

/**
 *
 * @author Fer
 */
public class Tablero {

    public static void main(String[] args) {
        int vidaCelula[][] = new int[5][5];
        Scanner entrada = new Scanner(System.in);
        int cViva;
        int cMuerta;
        for (int i = 0; i < vidaCelula.length; i++) {
            for (int j = 0; j < vidaCelula[i].length; j++) {
                System.out.println("Introduzca el elemento [" + i + "," + j + "]:");
                vidaCelula[i][j] = entrada.nextInt();
            }
        }
        System.out.println("");
        for (int i = 0; i < vidaCelula.length; i++) {
            for (int j = 0; j < vidaCelula[i].length; j++) {
                System.out.print(vidaCelula[i][j]);
                System.out.print("\t");
            }
            System.out.println("");
        }
        System.out.println("");
        for (int i = 0; i < vidaCelula.length; i++) {
            for (int j = 0; j < vidaCelula[i].length; j++) {
                if(vidaCelula[i][j] == 1){
                    cViva=vidaCelula[i][j];
                    System.out.print("Celula Viva");
                }else if(vidaCelula[i][j] == 0){
                        cMuerta=vidaCelula[i][j];
                        System.out.print("Celula Muerta");
                        }
                System.out.print("\t");
            }
            System.out.println("");
        }
    }
}
